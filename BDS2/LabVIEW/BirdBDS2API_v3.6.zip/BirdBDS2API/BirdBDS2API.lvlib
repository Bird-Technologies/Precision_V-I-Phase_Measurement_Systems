﻿<?xml version='1.0' encoding='UTF-8'?>
<Library LVVersion="25008000">
	<Property Name="NI.Lib.Icon" Type="Bin">*1#!!!!!!!)!"1!&amp;!!!-!%!!!@````]!!!!"!!%!!!+U!!!*Q(C=\:;R;BN"%):`RY'EV2M%Y39)UMQL#!)OTJ8)']Q$R)6;JV-8=$&gt;QE#+Y52M1'"6ZA='&amp;?LW#8E(Z&lt;G]NSRD*#31E289V?X@`\-R]WFU&gt;EEJ\,&lt;X5^LGG9WW%`_RQ'[U[0UE7C_WCPTQ;WNZ@P)N[W2`;\:0Y2X@0RD_K`R3CT\]YW%J]URZOK_0@P\GPXT2]OL:N_K&gt;O;0LV08PQ&amp;P`?U/\(^X(.@&lt;&lt;SN.L&amp;\W)?YJNGNXZ6?YCP1YFP$L&lt;WP``P_U@(T^^I&gt;;T^T-`\[NF*@\B**_J?2&amp;BCA4FG[FT&lt;2%`U2%`U2%`U1!`U1!`U1!^U2X&gt;U2X&gt;U2X&gt;U1T&gt;U1T&gt;U1T@UUN'&amp;,H3BMSJ*];21ED2*E%Q'2=G1]#1]#5`#Q[-3HI1HY5FY%B[G+/&amp;*?"+?B#@B)5Q*4]+4]#1]#1_J#EG7DAZ0QE.["4Q"4]!4]!1]F&amp;4!%Q!%R9,%12)Q&amp;$C$GY!HY!FYO&amp;8!%`!%0!&amp;0Q).&lt;!5`!%`!%0!%0)766IN"U(2U?UMDB=8A=(I@(Y3'V("[(R_&amp;R?"Q?SMHB=8A=#+?AERQ%/5(/"/@"Y8&amp;YO-DB=8A=(I@(Y=&amp;6&gt;MD,SH1U85?(R_!R?!Q?A]@A)95-(I0(Y$&amp;Y$"\3SO!R?!Q?A]@AI:1-(I0(Y$&amp;!D++5FZ(-#$1G'9,"Q[?=&amp;CO\&amp;)8%3J@KY65^F+K(4@51K2Y/V5V8X5T646*&gt;@.6&amp;66UMV561`8+KU+IQKE65A\O*WD#OM35WRW&lt;9&amp;*NA9WS)$&lt;L1XTRRM^FIP6ZLO6RK0J^L.JNJ/JVK-JFI0"ZL/"RK-"DM`E[]I@@NZ0[^&gt;-5^&gt;NL?XEWP&lt;^Z?N,@P,MLVZG[+`OJ,0_?U`84Z_@LE`%0\\30_]`@NV]MPH@^8L=PX@@&gt;?_B@?D8KB\&gt;\@-.&lt;I"ZA\N&gt;I!!!!!</Property>
	<Property Name="NI.Lib.SourceVersion" Type="Int">620789760</Property>
	<Property Name="NI.Lib.Version" Type="Str">1.0.0.0</Property>
	<Item Name="Action-Status" Type="Folder">
		<Item Name="bds2dll get Attenuation.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll get Attenuation.vi"/>
		<Item Name="bds2dll get Avg Config.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll get Avg Config.vi"/>
		<Item Name="bds2dll get Last Error.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll get Last Error.vi"/>
		<Item Name="bds2dll get Std Config.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll get Std Config.vi"/>
		<Item Name="bds2dll init Attenuation.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll init Attenuation.vi"/>
		<Item Name="bds2dll init Std Config.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll init Std Config.vi"/>
		<Item Name="bds2dll start Scan.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll start Scan.vi"/>
		<Item Name="bds2dll stop Scan.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll stop Scan.vi"/>
	</Item>
	<Item Name="Configure" Type="Folder">
		<Property Name="NI.SortType" Type="Int">3</Property>
		<Item Name="bds2dll Configure Attenuation Settings.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll Configure Attenuation Settings.vi"/>
		<Item Name="bds2dll Configure Averaging Settings.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll Configure Averaging Settings.vi"/>
		<Item Name="bds2dll Configure Display Update Rate.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll Configure Display Update Rate.vi"/>
		<Item Name="bds2dll Configure Fundamental Count.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll Configure Fundamental Count.vi"/>
		<Item Name="bds2dll Configure Fundamental Frequencies.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll Configure Fundamental Frequencies.vi"/>
		<Item Name="bds2dll Configure Fundamental Frequencies NO SET.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll Configure Fundamental Frequencies NO SET.vi"/>
		<Item Name="bds2dll Configure Intermodulation.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll Configure Intermodulation.vi"/>
		<Item Name="bds2dll Configure Mode and Tracking Characteristics.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll Configure Mode and Tracking Characteristics.vi"/>
		<Item Name="bds2dll set Attenuation.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll set Attenuation.vi"/>
		<Item Name="bds2dll set Avg Config.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll set Avg Config.vi"/>
		<Item Name="bds2dll set Std Config.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll set Std Config.vi"/>
	</Item>
	<Item Name="Custom Controls" Type="Folder">
		<Item Name="Attenuation Selection Translator.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/Attenuation Selection Translator.vi"/>
		<Item Name="BDS2_Fundamental.ctl" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/Custom Controls/BDS2_Fundamental.ctl"/>
		<Item Name="BDS2_MultiState.ctl" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/Custom Controls/BDS2_MultiState.ctl"/>
		<Item Name="Convert 128 Char Bundle Into String.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/Custom Controls/Convert 128 Char Bundle Into String.vi"/>
		<Item Name="Convert DLL Revision Cluster.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/Custom Controls/Convert DLL Revision Cluster.vi"/>
	</Item>
	<Item Name="Data" Type="Folder">
		<Item Name="bds2dll Get Number of Measurements.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll Get Number of Measurements.vi"/>
		<Item Name="bds2dll get Std Single Dataset.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll get Std Single Dataset.vi"/>
	</Item>
	<Item Name="Examples" Type="Folder">
		<Item Name="BDS2 Example 01 Standard Tracking Mode.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/BDS2 Example 01 Standard Tracking Mode.vi"/>
		<Item Name="BDS2 Example 02 Sequenced Standard Tracking Mode.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/BDS2 Example 02 Sequenced Standard Tracking Mode.vi"/>
	</Item>
	<Item Name="Sub-VI" Type="Folder"/>
	<Item Name="Utilities" Type="Folder">
		<Item Name="bds2dll finalize.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll finalize.vi"/>
		<Item Name="bds2dll get BDS2Revision.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll get BDS2Revision.vi"/>
		<Item Name="bds2dll get DLL Revision_ALT_2.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll get DLL Revision_ALT_2.vi"/>
		<Item Name="bds2dll get System Info.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll get System Info.vi"/>
		<Item Name="bds2dll get System Time.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll get System Time.vi"/>
		<Item Name="bds2dll set System Time.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll set System Time.vi"/>
		<Item Name="Error Converter (ErrCode or Status).vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/Error Converter (ErrCode or Status).vi"/>
	</Item>
	<Item Name="bds2dll connect TCPIP.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll connect TCPIP.vi"/>
	<Item Name="bds2dll disconnect.vi" Type="VI" URL="/&lt;userlib&gt;/BirdBDS2API/VIs/bds2dll disconnect.vi"/>
</Library>
